console.log("[2VIA] Content script carregado.");

let processando = false;
const MODO_TESTE = true;

const MENSAGEM_LOCALIZACAO = 
`Poderia me enviar sua localização fixa para ser anexada, por gentileza? 😊
No WhatsApp, no campo de digitação, tem o desenho de um clips, clicando nele terá "Localização" e depois "Localização Atual". Consegue me mandar dessa forma?
`

const MENSAGEM_REDE = `💻 Passo 1 – Acesse as configurações de rede

Clique no botão Iniciar do Windows.

Digite Painel de Controle e abra.

Vá em Rede e Internet > Central de Rede e Compartilhamento.

No menu à esquerda, clique em Alterar as configurações do adaptador.

💻 Passo 2 – Verifique a conexão

Encontre a conexão em uso (Ethernet se for cabo ou Wi-Fi se for sem fio).

Clique com o botão direito e selecione Status.

Na janela que abrir, olhe o campo Velocidade.

📊 Como interpretar o resultado:

1,0 Gbps (ou 1000 Mbps) → Seu computador suporta até 1 Giga. ✅ Vai aproveitar normalmente planos de 800 Mega.

100 Mbps → Seu computador suporta no máximo 100 Mega. ❌ Não conseguirá usar toda a velocidade de 800 Mega.
`

const MENSAGEM_PORTAL1 = 
`🔗 Acesso ao Portal do Assinante
🌐 portal.maisinternet.net.br
👤 Login: seu CPF (apenas números)
🔑 Senha: maisinternet`

const MENSAGEM_PORTAL = `🔗 Acesso ao Portal do Assinante

🌐 portal.maisinternet.net.br
👤 Login: seu CPF (apenas números)
🔑 Senha: maisinternet

🚀 Passo a passo para pagamento

1. Acesse o Portal e faça login.
2. No menu principal, clique em "Faturas".
3. Escolha a fatura desejada e clique em "Pagar agora".

💳 Formas de pagamento

• Pix: gera QR Code ou código Copia e Cola.
• Boleto: disponibiliza o código de barras.
• Cartão de Crédito: paga somente a fatura selecionada.
• Cartão Recorrente: paga a fatura atual e cadastra o cartão para as próximas cobranças.

🖨️ Como visualizar ou imprimir o boleto em PDF

1. Na tela de faturas, localize a conta desejada.
2. Clique em "Ver mais" ou nos três pontinhos.
3. Selecione "Ver Fatura".
4. O PDF será aberto para visualização, salvamento ou impressão.

💡 Dica: com o Cartão Recorrente, o pagamento das próximas faturas fica cadastrado automaticamente.`;


const MODO_TESTE_IMAGENS = false;

const COMANDOS_IMAGEM = {

    "/portal": {
        imagem: "images/portal.png",
        nome: "Como acessar o Portal.png",
        mensagem: MENSAGEM_PORTAL1
    },

    "/lugar": {
        imagem: "images/localizacao.png",
        nome: "Como enviar localização.png",
        mensagem: MENSAGEM_LOCALIZACAO
    },

    "/fatura": {
        imagem: "images/fatura.png",
        nome: "Como acessar a fatura.png",
        mensagem: MENSAGEM_PORTAL
    },

    "/rede": {
        imagem: "images/rede.png",
        nome: "Placa de rede Gigabit.png",
        mensagem: MENSAGEM_REDE
    }

};
// ==============================
// AGUARDAR BOTÃO ENVIAR
// ==============================

async function aguardarBotaoEnviar() {

    for (let tentativa = 0; tentativa < 40; tentativa++) {

        const botao = document.querySelector(
            "#message-send"
        );

        if (
            botao &&
            !botao.disabled &&
            botao.offsetParent !== null
        ) {
            return botao;
        }

        await new Promise(
            resolve => setTimeout(resolve, 250)
        );
    }

    throw new Error(
        "Botão de enviar não ficou disponível."
    );
}


// ==============================
// PREENCHER EDITOR
// ==============================

function preencherEditor(texto) {

    const editor = document.querySelector(
        ".emojionearea-editor"
    );

    if (!editor) {
        throw new Error(
            "Editor de mensagem não encontrado."
        );
    }

    editor.focus();

    // Limpa o conteúdo atual
    editor.innerHTML = "";

    // Cria as quebras de linha corretamente
    const linhas = texto.split("\n");

    linhas.forEach((linha, indice) => {

        if (linha) {
            editor.appendChild(
                document.createTextNode(linha)
            );
        }

        // Adiciona quebra, exceto depois da última linha
        if (indice < linhas.length - 1) {
            editor.appendChild(
                document.createElement("br")
            );
        }
    });

    editor.dispatchEvent(
        new InputEvent(
            "input",
            {
                bubbles: true,
                inputType: "insertText",
                data: texto
            }
        )
    );

    editor.dispatchEvent(
        new Event(
            "change",
            {
                bubbles: true
            }
        )
    );

    return true;
}


// ==============================
// ENVIAR MENSAGEM
// ==============================

async function enviarMensagemAtual() {

    const botao =
        await aguardarBotaoEnviar();

    botao.click();

    return true;
}
// ==============================
// PEGAR TEXTO DO EDITOR
// ==============================

function getEditor() {
    return document.querySelector(
        ".emojionearea-editor"
    );
}


function getTextoEditor() {
    const editor = getEditor();

    if (!editor) {
        return "";
    }

    return (editor.textContent || "").trim();
}


// ==============================
// LIMPAR EDITOR
// ==============================

function limparEditor() {
    const editor = getEditor();

    if (!editor) {
        return false;
    }

    editor.focus();
    editor.textContent = "";

    editor.dispatchEvent(
        new InputEvent("input", {
            bubbles: true,
            inputType: "deleteContentBackward",
            data: null
        })
    );

    editor.dispatchEvent(
        new Event("change", {
            bubbles: true
        })
    );

    return true;
}
// ==============================
        // BASE64 -> ARQUIVO
        // ==============================

        function base64ParaArquivo(
            base64,
            nomeArquivo,
            tipo = "application/pdf"
        ) {

            const binario = atob(base64);

            const bytes = new Uint8Array(
                binario.length
            );

            for (
                let i = 0;
                i < binario.length;
                i++
            ) {

                bytes[i] =
                    binario.charCodeAt(i);
            }

            return new File(
                [bytes],
                nomeArquivo,
                {
                    type: tipo
                }
            );
        }


        // ==============================
        // ANEXAR PDF NO PIPE
        // ==============================

        async function anexarArquivoNoPipe(arquivo) {

            console.log(
                "[2VIA] Preparando campo de anexos..."
            );

            let input = document.querySelector(
                'input.dz-hidden-input[type="file"]'
            );

            // Se o Dropzone ainda não criou o input,
            // acionamos o botão de anexos do Pipe.
            if (!input) {

                console.log(
                    "[2VIA] Input Dropzone ainda não existe."
                );

                const botaoClipe = document.querySelector(
                    "#talk-select-files"
                );

                if (!botaoClipe) {
                    throw new Error(
                        "Botão de anexos #talk-select-files não encontrado."
                    );
                }

                console.log(
                    "[2VIA] Inicializando área de anexos..."
                );

                botaoClipe.click();

                // Aguarda o Pipe criar o dz-hidden-input
                for (
                    let tentativa = 0;
                    tentativa < 20;
                    tentativa++
                ) {

                    await new Promise(
                        resolve =>
                            setTimeout(resolve, 250)
                    );

                    const inputs = [
                        ...document.querySelectorAll(
                            'input.dz-hidden-input[type="file"]'
                        )
                    ];

                    if (inputs.length > 0) {

                        // Usa o mais recente
                        input =
                            inputs[
                                inputs.length - 1
                            ];

                        break;
                    }
                }
            }

            if (!input) {
                throw new Error(
                    "O Pipe não criou o input de anexos."
                );
            }

            console.log(
                "[2VIA] Input Dropzone encontrado."
            );

            console.log(
                "[2VIA] Accept:",
                input.accept
            );

            const transferencia =
                new DataTransfer();

            transferencia.items.add(
                arquivo
            );

            input.files =
                transferencia.files;

            console.log(
                "[2VIA] Entregando arquivo:",
                arquivo.name,
                arquivo.size,
                arquivo.type
            );

            input.dispatchEvent(
                new Event(
                    "change",
                    {
                        bubbles: true
                    }
                )
            );

            console.log(
                "[2VIA] Evento change disparado."
            );

            return true;
}
       //================================
       // CONFIRMAR ARQUIVO
       //================================
        async function confirmarCarregamentoArquivo() {

    console.log(
        "[2VIA] Aguardando botão 'Carregar arquivo'..."
    );

    let botao = null;

    for (
        let tentativa = 0;
        tentativa < 20;
        tentativa++
    ) {

        botao = document.querySelector(
            "#btn-confirm-select-files"
        );

        if (
            botao &&
            !botao.disabled &&
            botao.offsetParent !== null
        ) {
            break;
        }

        await new Promise(
            resolve => setTimeout(resolve, 250)
        );
    }

    if (!botao) {
        throw new Error(
            "Botão 'Carregar arquivo' não encontrado."
        );
    }

    console.log(
        "[2VIA] Botão 'Carregar arquivo' encontrado."
    );

    botao.click();

    console.log(
        "[2VIA] Clique em 'Carregar arquivo' realizado."
    );

    return true;
}

// ==============================
// PEGAR CPF / CNPJ
// ==============================

function getDocumentoCliente() {

    const elemento = document.querySelector(
        "#customer-document-number-info"
    );

    if (!elemento) {
        return null;
    }

    const texto = elemento.textContent || "";

    const documento = texto.replace(
        /\D/g,
        ""
    );

    if (!documento) {
        return null;
    }

    return documento;
}

// ==============================
// CARREGAR ARQUIVO DA EXTENSÃO
// ==============================

async function carregarArquivoExtensao(
    caminho,
    nome
) {

    const url = chrome.runtime.getURL(
        caminho
    );

    console.log(
        "[ATALHOS] Carregando:",
        url
    );

    const resposta = await fetch(
        url
    );

    if (!resposta.ok) {

        throw new Error(
            `Não foi possível carregar ${caminho}`
        );
    }

    const blob = await resposta.blob();

    return new File(
        [blob],
        nome,
        {
            type: blob.type || "image/png"
        }
    );
}


// ==============================
// PROCESSAR COMANDO DE IMAGEM
// ==============================

async function processarComandoImagem(
    comandoTexto
) {

    const comando =
        comandoTexto.toLowerCase();

    const configuracao =
        COMANDOS_IMAGEM[comando];

    if (!configuracao) {
        return false;
    }


    if (processando) {

        console.log(
            "[ATALHOS] Já existe processamento em andamento."
        );

        return true;
    }


    processando = true;

    console.log(
        "[ATALHOS] Comando detectado:",
        comando
    );


    // Impede /portal, /loc etc.
    // de chegar ao cliente.
    limparEditor();


    try {

        // ==============================
        // CARREGAR PNG
        // ==============================

        const arquivo =
            await carregarArquivoExtensao(
                configuracao.imagem,
                configuracao.nome
            );


        console.log(
            "[ATALHOS] Imagem carregada:",
            arquivo.name,
            arquivo.size,
            arquivo.type
        );


        // ==============================
        // ENTREGAR AO PIPE
        // ==============================

        await anexarArquivoNoPipe(
            arquivo
        );


        console.log(
            "[ATALHOS] Imagem entregue ao seletor."
        );


        // ==============================
        // CLICAR CARREGAR ARQUIVO
        // ==============================

        await confirmarCarregamentoArquivo();


        console.log(
            "[ATALHOS] Imagem carregada no chat."
        );


        // Aguarda Pipe processar preview
        await new Promise(
            resolve =>
                setTimeout(resolve, 1000)
        );


        // Aguarda o Pipe terminar de montar
// o preview do anexo.
await new Promise(
    resolve => setTimeout(resolve, 1000)
);


// ==============================
// COLOCAR MENSAGEM
// ==============================

if (configuracao.mensagem) {

    console.log(
        "[ATALHOS] Preenchendo mensagem..."
    );

    preencherEditor(
        configuracao.mensagem
    );

    // Dá tempo do Pipe reconhecer
    // o conteúdo digitado.
    await new Promise(
        resolve => setTimeout(resolve, 500)
    );
}


// ==============================
// MODO TESTE
// ==============================

if (MODO_TESTE_IMAGENS) {

    console.log(
        "[ATALHOS] MODO TESTE: imagem e mensagem prontas, envio bloqueado."
    );

    processando = false;

    return true;
}


// ==============================
// ENVIAR IMAGEM + MENSAGEM
// ==============================

console.log(
    "[ATALHOS] Enviando imagem + mensagem..."
);

await enviarMensagemAtual();

console.log(
    "[ATALHOS] Imagem + mensagem enviadas."
);

processando = false;

return true;

    }
    catch (erro) {

        console.error(
            "[ATALHOS] Erro:",
            erro
        );

        processando = false;

        return true;
    }
}

// ==============================
// PROCESSAR /2VIA
// ==============================

function processarSegundaVia() {

    if (processando) {

        console.log(
            "[2VIA] Já existe um processamento em andamento."
        );

        return;
    }


    const texto = getTextoEditor();

    if (texto.toLowerCase() !== "/2via") {
        return;
    }


    processando = true;

    console.log(
        "[2VIA] Comando /2via detectado."
    );


    // Remove /2via para nunca chegar ao cliente
    limparEditor();


    const documento = getDocumentoCliente();

    if (!documento) {

        console.error(
            "[2VIA] CPF/CNPJ não encontrado no atendimento."
        );

        processando = false;
        return;
    }


    console.log(
        "[2VIA] Documento capturado:",
        documento
    );

    console.log(
        "[2VIA] Solicitando fatura ao Python..."
    );


    chrome.runtime.sendMessage(
        {
            tipo: "GERAR_2VIA",
            cpf: documento
        },

        resposta => {



            if (chrome.runtime.lastError) {

                console.error(
                    "[2VIA] Erro de comunicação:",
                    chrome.runtime.lastError.message
                );

                return;
            }


            if (!resposta) {

                console.error(
                    "[2VIA] O background não respondeu."
                );

                return;
            }


            if (!resposta.sucesso) {

            console.error(
                "[2VIA] Falha ao gerar fatura:",
                resposta
            );

            console.error(
                "[2VIA] DETALHES DO PYTHON:\n",
                resposta?.dados?.detalhes ||
                resposta?.dados?.erro ||
                resposta?.erro ||
                "Sem detalhes."
            );

            processando = false;
            return;
        }


            console.log(
                "[2VIA] Segunda via gerada com sucesso."
            );

            console.log(
                "[2VIA] Resposta:",
                resposta.dados
            );


            if (resposta.dados?.url_pdf) {

            console.log(
                "[2VIA] URL PDF:",
                resposta.dados.url_pdf
            );


            const urlPdf =
                resposta.dados.url_pdf;

            const nomeArquivo =
                resposta.dados.nome_arquivo ||
                `${resposta.dados.cliente}.pdf`;


            console.log(
                "[2VIA] Solicitando PDF ao background..."
            );


            chrome.runtime.sendMessage(
                {
                    tipo: "BAIXAR_PDF",
                    url: urlPdf
                },

                async (respostaPdf) => {

                    if (
                        chrome.runtime.lastError
                    ) {

                        console.error(
                            "[2VIA] Erro ao receber PDF:",
                            chrome.runtime.lastError.message
                        );

                        return;
                    }


                    if (
                        !respostaPdf ||
                        !respostaPdf.sucesso
                    ) {

                        console.error(
                            "[2VIA] Falha ao baixar PDF:",
                            respostaPdf
                        );

                        return;
                    }


                    console.log(
                        "[2VIA] PDF recebido pela extensão:",
                        respostaPdf.tamanho,
                        "bytes"
                    );


                    try {

                        const arquivo =
                            base64ParaArquivo(
                                respostaPdf.base64,
                                nomeArquivo,
                                respostaPdf.tipo
                            );


                        console.log(
                            "[2VIA] Arquivo criado:",
                            arquivo.name,
                            arquivo.size,
                            arquivo.type
                        );


                        await anexarArquivoNoPipe(
                            arquivo
                        );

                        console.log(
                            "[2VIA] PDF entregue ao campo de seleção."
                        );


                        await confirmarCarregamentoArquivo();

                        console.log(
                            "[2VIA] PDF carregado para o chat."
                        );


                        // Dá um pequeno tempo para o Pipe
                        // finalizar o processamento do anexo.
                        await new Promise(
                            resolve => setTimeout(resolve, 1000)
                        );


                        // ==============================
                        // ENVIAR PDF
                        // ==============================

                        if (MODO_TESTE) {

                        console.log(
                            "[2VIA] MODO TESTE: PDF carregado, envio bloqueado."
                        );

                        processando = false;

                        return;
                    }

                    console.log(
                        "[2VIA] Enviando PDF..."
                    );

                    

                        console.log(
                            "[2VIA] Orientação enviada."
                        );

                        console.log(
                            "[2VIA] Processo /2via concluído."
                        );

                        processando = false;

                    }
                    catch (erro) {

                        console.error(
                            "[2VIA] Erro ao anexar:",
                            erro
                        );
                    }
                }
            );
        }


            if (resposta.dados?.vencimento) {

                console.log(
                    "[2VIA] Vencimento:",
                    resposta.dados.vencimento
                );
            }


            if (resposta.dados?.arquivo) {

                console.log(
                    "[2VIA] Arquivo:",
                    resposta.dados.arquivo
                );
            }


            if (resposta.dados?.url_pdf) {

                console.log(
                    "[2VIA] URL PDF:",
                    resposta.dados.url_pdf
                );
            }

        }
    );
    
}


// ==============================
// ENTER NO EDITOR
// ==============================

document.addEventListener(
    "keydown",
    event => {

        const editor =
            event.target.closest?.(
                ".emojionearea-editor"
            );

        if (!editor) {
            return;
        }


        if (
            event.key !== "Enter" ||
            event.shiftKey
        ) {
            return;
        }


        const texto =
            getTextoEditor()
                .toLowerCase();


        const eh2Via =
            texto === "/2via";

        const ehImagem =
            Object.prototype.hasOwnProperty.call(
                COMANDOS_IMAGEM,
                texto
            );


        // Se não for comando nosso,
        // deixa o Pipe funcionar normalmente.
        if (
            !eh2Via &&
            !ehImagem
        ) {
            return;
        }


        // Impede o Pipe de mandar
        // o comando escrito.
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();


        if (eh2Via) {

            processarSegundaVia();

            return;
        }


        processarComandoImagem(
            texto
        );
    },
    true
);

document.addEventListener(
    "keydown",
    event => {

        const editor = event.target.closest?.(
            ".emojionearea-editor"
        );

        if (!editor) {
            return;
        }

        if (
            event.key !== "Enter" ||
            event.shiftKey
        ) {
            return;
        }

        const texto = getTextoEditor();

        if (
            texto.toLowerCase() !== "/2via"
        ) {
            return;
        }

        // Bloqueia o Enter antes que
        // o Pipe envie "/2via"
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();

        processarSegundaVia();
    }
);


// ==============================
// CLIQUE NO BOTÃO ENVIAR
// ==============================

document.addEventListener(
    "click",
    event => {

        const botao =
            event.target.closest?.(
                "#message-send"
            );

        if (!botao) {
            return;
        }


        const texto =
            getTextoEditor()
                .toLowerCase();


        const eh2Via =
            texto === "/2via";

        const ehImagem =
            Object.prototype.hasOwnProperty.call(
                COMANDOS_IMAGEM,
                texto
            );


        if (
            !eh2Via &&
            !ehImagem
        ) {
            return;
        }


        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();


        if (eh2Via) {

            processarSegundaVia();

            return;
        }


        processarComandoImagem(
            texto
        );

    },
    true
);
// ==============================
// TESTE DO SERVIDOR LOCAL
// ==============================

chrome.runtime.sendMessage(
    {
        tipo: "TESTAR_SERVIDOR"
    },
    resposta => {

        if (chrome.runtime.lastError) {

            console.error(
                "[2VIA] Erro de comunicação:",
                chrome.runtime.lastError.message
            );

            return;
        }

        console.log(
            "[2VIA] Servidor local:",
            resposta
        );
    }
);