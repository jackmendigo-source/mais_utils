console.log("[2VIA] Background iniciado.");

chrome.runtime.onMessage.addListener(
    (mensagem, sender, sendResponse) => {

        // ==============================
        // BAIXAR PDF PARA ANEXO
        // ==============================

        if (mensagem.tipo === "BAIXAR_PDF") {

            console.log(
                "[2VIA] Baixando PDF para anexar..."
            );

            fetch(mensagem.url)
                .then(async resposta => {

                    if (!resposta.ok) {
                        throw new Error(
                            `HTTP ${resposta.status}`
                        );
                    }

                    const arrayBuffer =
                        await resposta.arrayBuffer();

                    const bytes =
                        new Uint8Array(arrayBuffer);

                    // Converte os bytes para Base64
                    // para conseguirmos mandar pelo
                    // chrome.runtime.sendMessage.
                    let binario = "";

                    const tamanhoBloco = 0x8000;

                    for (
                        let i = 0;
                        i < bytes.length;
                        i += tamanhoBloco
                    ) {

                        const bloco = bytes.subarray(
                            i,
                            Math.min(
                                i + tamanhoBloco,
                                bytes.length
                            )
                        );

                        binario += String.fromCharCode(
                            ...bloco
                        );
                    }

                    const base64 = btoa(binario);

                    console.log(
                        "[2VIA] PDF baixado:",
                        bytes.length,
                        "bytes"
                    );

                    sendResponse({
                        sucesso: true,
                        base64: base64,
                        tipo: "application/pdf",
                        tamanho: bytes.length
                    });

                })
                .catch(erro => {

                    console.error(
                        "[2VIA] Erro ao baixar PDF:",
                        erro
                    );

                    sendResponse({
                        sucesso: false,
                        erro: String(erro)
                    });

                });

            return true;
        }
        // ==============================
        // TESTAR SERVIDOR
        // ==============================

        if (mensagem.tipo === "TESTAR_SERVIDOR") {

            fetch("http://127.0.0.1:8765/status")
                .then(async resposta => {

                    const dados = await resposta.json();

                    sendResponse({
                        sucesso: true,
                        http: resposta.status,
                        dados: dados
                    });

                })
                .catch(erro => {

                    sendResponse({
                        sucesso: false,
                        erro: String(erro)
                    });

                });

            return true;
        }


        // ==============================
        // GERAR SEGUNDA VIA
        // ==============================

        if (mensagem.tipo === "GERAR_2VIA") {

            console.log(
                "[2VIA] Solicitando segunda via..."
            );

            fetch(
                "http://127.0.0.1:8765/2via",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        cpf: mensagem.cpf
                    })
                }
            )
                .then(async resposta => {

                    let dados;

                    try {
                        dados = await resposta.json();
                    }
                    catch {
                        dados = {};
                    }

                    if (!resposta.ok) {

                        sendResponse({
                            sucesso: false,
                            http: resposta.status,
                            erro:
                                dados.erro ||
                                "Erro ao gerar segunda via.",
                            dados: dados
                        });

                        return;
                    }

                    sendResponse({
                        sucesso: true,
                        http: resposta.status,
                        dados: dados
                    });

                })
                .catch(erro => {

                    console.error(
                        "[2VIA] Erro no servidor:",
                        erro
                    );

                    sendResponse({
                        sucesso: false,
                        erro: String(erro)
                    });

                });

            return true;
        }
    }
);