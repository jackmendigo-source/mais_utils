from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.db import IntegrityError
from django.db import transaction as db_transaction
from django.test import TestCase

from accounts.models import Account
from transactions.models import Category, Transaction, TransactionType
from transactions.services import create_transaction


User = get_user_model()

class TransactionModelTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user(
            username="teste",
            password="senha-segura-123",
        )

        cls.account = Account.objects.create(
            user=cls.user,
            name="Conta principal",
            opening_balance=Decimal("1000.00"),
        )

        cls.category = Category.objects.create(
            user=cls.user,
            name="Alimentação",
            type=TransactionType.EXPENSE,
        )

    #teste de criação de transação válida
    
    def test_can_create_valid_transaction(self):
        transaction = Transaction.objects.create(
            account=self.account,
            category=self.category,
            type=TransactionType.EXPENSE,
            amount=Decimal("50.00"),
            description="Mercado",
            occurred_on="2026-09-23",
        )

        self.assertEqual(transaction.amount, Decimal("50.00"))

    #teste da transação não pode ser zero

    def test_transaction_amount_cannot_be_zero(self):
        with self.assertRaises(IntegrityError):
            with db_transaction.atomic():
                Transaction.objects.create(
                    account=self.account,
                    category=self.category,
                    type=TransactionType.EXPENSE,
                    amount=Decimal("0.00"),
                    description="Valor inválido",
                    occurred_on="2026-09-23",
                )

    #definindo que a transação não pode ser negativa
    
    def test_transaction_amount_cannot_be_negative(self):
        with self.assertRaises(IntegrityError):
            with db_transaction.atomic():
                Transaction.objects.create(
                    account=self.account,
                    category=self.category,
                    type=TransactionType.EXPENSE,
                    amount=Decimal("-50.00"),
                    description="Valor inválido",
                    occurred_on="2026-09-23",
                )
    
    #Criar teste de criação válida
    
    def test_service_creates_valid_transaction(self):
        transaction = create_transaction(
            account=self.account,
            category=self.category,
            transaction_type=TransactionType.EXPENSE,
            amount="75.90",
            description="Supermercado",
            occurred_on="2026-09-23",
        )

        self.assertEqual(transaction.amount, Decimal("75.90"))
        self.assertEqual(
            transaction.account.user,
            self.user,
        )
    
    #teste para verificar se o usuário consegue criar uma transação com uma categoria de outro usuário, o que não deve ser permitido.
      
    def test_cannot_use_category_from_another_user(self):
        other_user = User.objects.create_user(
            username="outro_usuario",
            password="outra-senha-segura-123",
        )

        other_category = Category.objects.create(
            user=other_user,
            name="Outra categoria",
            type=TransactionType.EXPENSE,
        )

        with self.assertRaises(ValidationError):
            create_transaction(
                account=self.account,
                category=other_category,
                transaction_type=TransactionType.EXPENSE,
                amount="100.00",
                occurred_on="2026-09-23",
            )
    
    #teste para verificar se o usuário consegue criar uma transação de despesa usando uma categoria de receita, o que não deve ser permitido.
            
    def test_expense_cannot_use_income_category(self):
        income_category = Category.objects.create(
            user=self.user,
            name="Salário",
            type=TransactionType.INCOME,
        )

        with self.assertRaises(ValidationError):
            create_transaction(
                account=self.account,
                category=income_category,
                transaction_type=TransactionType.EXPENSE,
                amount="100.00",
                occurred_on="2026-09-23",
            )
            
    def test_service_creates_valid_income_transaction(self):
        income_category = Category.objects.create(
            user=self.user,
            name="Salário",
            type=TransactionType.INCOME,
        )

        transaction = create_transaction(
            account=self.account,
            category=income_category,
            transaction_type=TransactionType.INCOME,
            amount="2500.00",
            description="Salário",
            occurred_on="2026-09-23",
        )

        self.assertEqual(transaction.amount, Decimal("2500.00"))
        self.assertEqual(transaction.type, TransactionType.INCOME)
        self.assertEqual(transaction.category, income_category)

