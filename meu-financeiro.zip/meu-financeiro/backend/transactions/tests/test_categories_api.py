
from django.contrib.auth import get_user_model

from rest_framework import status
from rest_framework.test import APITestCase

from transactions.models import Category, TransactionType


User = get_user_model()

class CategoryAPITests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username="joao_categoria",
            password="senha-segura-123",
        )

        self.other_user = User.objects.create_user(
            username="maria_categoria",
            password="senha-segura-456",
        )

        self.category = Category.objects.create(
            user=self.user,
            name="Alimentação",
            type=TransactionType.EXPENSE,
        )

        Category.objects.create(
            user=self.other_user,
            name="Categoria da Maria",
            type=TransactionType.EXPENSE,
        )

    def test_unauthenticated_user_cannot_list_categories(self):
        response = self.client.get("/api/categories/")

        self.assertIn(
            response.status_code,
            [
                status.HTTP_401_UNAUTHORIZED,
                status.HTTP_403_FORBIDDEN,
            ],
        )

    def test_user_only_sees_own_categories(self):
        self.client.force_authenticate(user=self.user)

        response = self.client.get("/api/categories/")

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )

        self.assertEqual(
            len(response.data),
            1,
        )

        self.assertEqual(
            response.data[0]["name"],
            "Alimentação",
        )

    def test_authenticated_user_can_create_category(self):
        self.client.force_authenticate(user=self.user)

        data = {
            "name": "Salário",
            "type": TransactionType.INCOME,
        }

        response = self.client.post(
            "/api/categories/",
            data,
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_201_CREATED,
        )

        category = Category.objects.get(
            user=self.user,
            name="Salário",
        )

        self.assertEqual(
            category.type,
            TransactionType.INCOME,
        )

    def test_cannot_create_category_with_invalid_type(self):
        self.client.force_authenticate(user=self.user)

        data = {
            "name": "Categoria inválida",
            "type": "INVALID",
        }

        response = self.client.post(
            "/api/categories/",
            data,
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_400_BAD_REQUEST,
        )
        
