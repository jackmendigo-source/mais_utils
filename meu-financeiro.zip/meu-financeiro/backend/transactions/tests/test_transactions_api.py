from decimal import Decimal

from django.contrib.auth import get_user_model

from rest_framework import status
from rest_framework.test import APITestCase

from accounts.models import Account
from transactions.models import Category, Transaction, TransactionType


User = get_user_model()

class TransactionAPITests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username="joao_transacao",
            password="senha-segura-123",
        )

        self.other_user = User.objects.create_user(
            username="maria_transacao",
            password="senha-segura-456",
        )

        self.account = Account.objects.create(
            user=self.user,
            name="Conta do João",
            opening_balance=Decimal("1000.00"),
        )

        self.category = Category.objects.create(
            user=self.user,
            name="Alimentação",
            type=TransactionType.EXPENSE,
        )

        self.other_account = Account.objects.create(
            user=self.other_user,
            name="Conta da Maria",
            opening_balance=Decimal("5000.00"),
        )

        self.other_category = Category.objects.create(
            user=self.other_user,
            name="Categoria da Maria",
            type=TransactionType.EXPENSE,
        )

        Transaction.objects.create(
            account=self.account,
            category=self.category,
            type=TransactionType.EXPENSE,
            amount=Decimal("50.00"),
            description="Mercado",
            occurred_on="2026-09-23",
        )

        Transaction.objects.create(
            account=self.other_account,
            category=self.other_category,
            type=TransactionType.EXPENSE,
            amount=Decimal("999.00"),
            description="Compra da Maria",
            occurred_on="2026-09-23",
        )
        
    def test_user_cannot_use_another_users_account(self):
        self.client.force_authenticate(
            user=self.user
        )

        data = {
            "account": self.other_account.id,
            "category": self.category.id,
            "type": TransactionType.EXPENSE,
            "amount": "100.00",
            "description": "Tentativa inválida",
            "occurred_on": "2026-09-23",
        }

        response = self.client.post(
            "/api/transactions/",
            data,
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_400_BAD_REQUEST,
        )

    def test_user_cannot_use_another_users_category(self):
        self.client.force_authenticate(
            user=self.user
        )

        data = {
            "account": self.account.id,
            "category": self.other_category.id,
            "type": TransactionType.EXPENSE,
            "amount": "100.00",
            "description": "Tentativa inválida",
            "occurred_on": "2026-09-23",
        }

        response = self.client.post(
            "/api/transactions/",
            data,
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_400_BAD_REQUEST,
        )

    def test_expense_cannot_use_income_category_through_api(self):
        income_category = Category.objects.create(
            user=self.user,
            name="Salário",
            type=TransactionType.INCOME,
        )

        self.client.force_authenticate(
            user=self.user
        )

        data = {
            "account": self.account.id,
            "category": income_category.id,
            "type": TransactionType.EXPENSE,
            "amount": "100.00",
            "description": "Tipo incompatível",
            "occurred_on": "2026-09-23",
        }

        response = self.client.post(
            "/api/transactions/",
            data,
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_400_BAD_REQUEST,
        )
    def test_unauthenticated_user_cannot_list_transactions(self):
        response = self.client.get("/api/transactions/")

        self.assertIn(
            response.status_code,
            [
                status.HTTP_401_UNAUTHORIZED,
                status.HTTP_403_FORBIDDEN,
            ],
        )
    def test_user_only_sees_own_transactions(self):
        self.client.force_authenticate(user=self.user)

        response = self.client.get("/api/transactions/")

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )

        self.assertEqual(len(response.data), 1)

        self.assertEqual(
            response.data[0]["description"],
            "Mercado",
        )       
         
    def test_authenticated_user_can_create_transaction(self):
        self.client.force_authenticate(user=self.user)

        data = {
            "account": self.account.id,
            "category": self.category.id,
            "type": TransactionType.EXPENSE,
            "amount": "75.90",
            "description": "Supermercado",
            "occurred_on": "2026-09-23",
        }

        response = self.client.post(
            "/api/transactions/",
            data,
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_201_CREATED,
        )

        transaction = Transaction.objects.get(
            description="Supermercado"
        )

        self.assertEqual(
            transaction.amount,
            Decimal("75.90"),
        )

        self.assertEqual(
            transaction.account,
            self.account,
        )

        self.assertEqual(
            transaction.category,
            self.category,
        )

        self.assertEqual(
            transaction.account.user,
            self.user,
        )
    def test_user_can_retrieve_own_transaction(self):
        self.client.force_authenticate(user=self.user)

        transaction = Transaction.objects.get(
            description="Mercado"
        )

        response = self.client.get(
            f"/api/transactions/{transaction.id}/"
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )

        self.assertEqual(
            response.data["description"],
            "Mercado",
        )
    def test_user_cannot_retrieve_another_users_transaction(self):
        self.client.force_authenticate(user=self.user)

        transaction = Transaction.objects.get(
            description="Compra da Maria"
        )

        response = self.client.get(
            f"/api/transactions/{transaction.id}/"
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_404_NOT_FOUND,
        )
    def test_user_can_update_transaction_description(self):
        self.client.force_authenticate(user=self.user)

        transaction = Transaction.objects.get(
            description="Mercado"
        )

        response = self.client.patch(
            f"/api/transactions/{transaction.id}/",
            {"description": "Compras do mês"},
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )

        transaction.refresh_from_db()

        self.assertEqual(
            transaction.description,
            "Compras do mês",
        )
    def test_user_cannot_update_another_users_transaction(self):
        self.client.force_authenticate(user=self.user)

        transaction = Transaction.objects.get(
            description="Compra da Maria"
        )

        response = self.client.patch(
            f"/api/transactions/{transaction.id}/",
            {"description": "Alteração indevida"},
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_404_NOT_FOUND,
        )

        transaction.refresh_from_db()

        self.assertEqual(
            transaction.description,
            "Compra da Maria",
        )
    
    def test_cannot_update_transaction_amount(self):
        self.client.force_authenticate(user=self.user)

        transaction = Transaction.objects.get(
            description="Mercado"
        )

        response = self.client.patch(
            f"/api/transactions/{transaction.id}/",
            {
                "description": "Mercado atualizado",
                "amount": "1.00",
            },
            format="json",
        )

        self.assertEqual(response.status_code, 200)

        transaction.refresh_from_db()

        self.assertEqual(
            transaction.description,
            "Mercado atualizado",
        )

        self.assertEqual(
            transaction.amount,
            Decimal("50.00"),
        )