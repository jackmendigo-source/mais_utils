from rest_framework.generics import (
    ListCreateAPIView,
    RetrieveUpdateAPIView,
)
from rest_framework.permissions import IsAuthenticated

from transactions.models import Category, Transaction
from transactions.serializers import (
    CategorySerializer,
    TransactionSerializer,
    TransactionDescriptionSerializer,
)


class CategoryListCreateView(ListCreateAPIView):
    serializer_class = CategorySerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Category.objects.filter(
            user=self.request.user
        ).order_by("name")

    def perform_create(self, serializer):
        serializer.save(
            user=self.request.user
        )
        
class TransactionListCreateView(ListCreateAPIView):
    serializer_class = TransactionSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return (
            Transaction.objects
            .filter(account__user=self.request.user)
            .select_related(
                "account",
                "category",
            )
            .order_by("-occurred_on", "-created_at")
        )
        
class TransactionDetailView(RetrieveUpdateAPIView):
    serializer_class = TransactionSerializer
    permission_classes = [IsAuthenticated]

    http_method_names = [
        "get",
        "patch",
        "head",
        "options",
    ]

    def get_queryset(self):
        return Transaction.objects.filter(
            account__user=self.request.user
        )

    def get_serializer_class(self):
        if self.request.method == "PATCH":
            return TransactionDescriptionSerializer

        return TransactionSerializer