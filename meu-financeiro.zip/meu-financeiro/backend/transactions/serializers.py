from django.core.exceptions import ValidationError as DjangoValidationError
from rest_framework import serializers

from accounts.models import Account
from transactions.models import Category, Transaction
from transactions.services import create_transaction

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category

        fields = [
            "id",
            "name",
            "type",
            "is_active",
            "created_at",
            "updated_at",
        ]

        read_only_fields = [
            "id",
            "created_at",
            "updated_at",
        ]

class TransactionSerializer(serializers.ModelSerializer):
    account = serializers.PrimaryKeyRelatedField(
        queryset=Account.objects.none(),
    )

    category = serializers.PrimaryKeyRelatedField(
        queryset=Category.objects.none(),
    )

    class Meta:
        model = Transaction

        fields = [
            "id",
            "account",
            "category",
            "type",
            "amount",
            "description",
            "occurred_on",
            "created_at",
            "updated_at",
        ]

        read_only_fields = [
            "id",
            "created_at",
            "updated_at",
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        request = self.context.get("request")

        if request and request.user.is_authenticated:
            self.fields["account"].queryset = Account.objects.filter(
                user=request.user,
                is_active=True,
            )

            self.fields["category"].queryset = Category.objects.filter(
                user=request.user,
                is_active=True,
            )

    def create(self, validated_data):
        try:
            return create_transaction(
                account=validated_data["account"],
                category=validated_data["category"],
                transaction_type=validated_data["type"],
                amount=validated_data["amount"],
                description=validated_data.get(
                    "description",
                    "",
                ),
                occurred_on=validated_data["occurred_on"],
            )

        except DjangoValidationError as exc:
            raise serializers.ValidationError(
                exc.messages
            ) from exc
            

class TransactionDescriptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Transaction
        fields = ["description"]