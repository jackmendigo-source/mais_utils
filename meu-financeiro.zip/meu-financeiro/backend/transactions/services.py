from decimal import Decimal

from django.core.exceptions import ValidationError

from transactions.models import Transaction


def create_transaction(
    *,
    account,
    category,
    transaction_type,
    amount,
    occurred_on,
    description="",
):
    if account.user_id != category.user_id:
        raise ValidationError(
            "A conta e a categoria devem pertencer ao mesmo usuário."
        )

    if category.type != transaction_type:
        raise ValidationError(
            "O tipo da categoria deve corresponder ao tipo da transação."
        )

    amount = Decimal(amount)

    return Transaction.objects.create(
        account=account,
        category=category,
        type=transaction_type,
        amount=amount,
        description=description,
        occurred_on=occurred_on,
    )