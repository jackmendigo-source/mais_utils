from django.contrib.auth import get_user_model
from rest_framework import status
from rest_framework.test import APITestCase


User = get_user_model()


class JWTAuthenticationTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username="usuario_jwt",
            password="senha-segura-123",
        )

    def test_user_can_obtain_access_and_refresh_tokens(self):
        response = self.client.post(
            "/api/auth/token/",
            {
                "username": "usuario_jwt",
                "password": "senha-segura-123",
            },
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )

        self.assertIn("access", response.data)
        self.assertIn("refresh", response.data)

    def test_invalid_password_cannot_obtain_token(self):
        response = self.client.post(
            "/api/auth/token/",
            {
                "username": "usuario_jwt",
                "password": "senha-errada",
            },
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_401_UNAUTHORIZED,
        )
        
class RegistrationAPITests(APITestCase):
    def test_user_can_register(self):
        data = {
            "username": "novo_usuario",
            "email": "novo@example.com",
            "password": "SenhaSegura123!",
            "password_confirm": "SenhaSegura123!",
        }

        response = self.client.post(
            "/api/auth/register/",
            data,
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_201_CREATED,
        )

        user = User.objects.get(
            username="novo_usuario"
        )

        self.assertEqual(
            user.email,
            "novo@example.com",
        )

        self.assertTrue(
            user.check_password("SenhaSegura123!")
        )

    def test_passwords_must_match(self):
        data = {
            "username": "usuario_teste",
            "email": "teste@example.com",
            "password": "SenhaSegura123!",
            "password_confirm": "SenhaDiferente123!",
        }

        response = self.client.post(
            "/api/auth/register/",
            data,
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_400_BAD_REQUEST,
        )

        self.assertFalse(
            User.objects.filter(
                username="usuario_teste"
            ).exists()
        )