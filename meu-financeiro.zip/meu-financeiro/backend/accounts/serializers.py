from rest_framework import serializers

from accounts.models import Account


class AccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = Account

        fields = [
            "id",
            "name",
            "type",
            "opening_balance",
            "currency",
            "is_active",
            "created_at",
            "updated_at",
        ]

        read_only_fields = [
            "id",
            "created_at",
            "updated_at",
        ]

class MonthlySummaryQuerySerializer(serializers.Serializer):
    year = serializers.IntegerField(
        min_value=1,
    )

    month = serializers.IntegerField(
        min_value=1,
        max_value=12,
    )