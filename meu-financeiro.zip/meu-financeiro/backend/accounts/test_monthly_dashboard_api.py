from decimal import Decimal

from django.contrib.auth import get_user_model

from rest_framework import status
from rest_framework.test import APITestCase

from accounts.models import Account
from transactions.models import (
    Category,
    Transaction,
    TransactionType,
)


User = get_user_model()


class DashboardMonthlySummaryAPITests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username="monthly_dashboard_user",
            password="senha-segura-123",
        )

        self.account = Account.objects.create(
            user=self.user,
            name="Conta principal",
            opening_balance=Decimal("1000.00"),
        )

        self.income_category = Category.objects.create(
            user=self.user,
            name="Salário",
            type=TransactionType.INCOME,
        )

        self.expense_category = Category.objects.create(
            user=self.user,
            name="Alimentação",
            type=TransactionType.EXPENSE,
        )

        Transaction.objects.create(
            account=self.account,
            category=self.income_category,
            type=TransactionType.INCOME,
            amount=Decimal("3000.00"),
            occurred_on="2026-09-05",
        )

        Transaction.objects.create(
            account=self.account,
            category=self.expense_category,
            type=TransactionType.EXPENSE,
            amount=Decimal("700.00"),
            occurred_on="2026-09-10",
        )

        Transaction.objects.create(
            account=self.account,
            category=self.expense_category,
            type=TransactionType.EXPENSE,
            amount=Decimal("900.00"),
            occurred_on="2026-08-10",
        )
    
    def test_unauthenticated_user_cannot_access_monthly_summary(self):
        response = self.client.get(
            "/api/dashboard/monthly/?year=2026&month=9"
        )

        self.assertIn(
            response.status_code,
            [
                status.HTTP_401_UNAUTHORIZED,
                status.HTTP_403_FORBIDDEN,
            ],
        )
    
    def test_authenticated_user_receives_monthly_summary(self):
        self.client.force_authenticate(
            user=self.user
        )

        response = self.client.get(
            "/api/dashboard/monthly/?year=2026&month=9"
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )

        self.assertEqual(
            response.data["year"],
            2026,
        )

        self.assertEqual(
            response.data["month"],
            9,
        )

        self.assertEqual(
            response.data["total_income"],
            Decimal("3000.00"),
        )

        self.assertEqual(
            response.data["total_expenses"],
            Decimal("700.00"),
        )

        self.assertEqual(
            response.data["net_result"],
            Decimal("2300.00"),
        )
    
    def test_invalid_month_returns_bad_request(self):
        self.client.force_authenticate(
            user=self.user
        )

        response = self.client.get(
            "/api/dashboard/monthly/?year=2026&month=15"
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_400_BAD_REQUEST,
        )
    
    def test_missing_parameters_return_bad_request(self):
        self.client.force_authenticate(
            user=self.user
        )

        response = self.client.get(
            "/api/dashboard/monthly/"
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_400_BAD_REQUEST,
        )