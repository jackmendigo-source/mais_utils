from decimal import Decimal
from accounts.models import Account
from django.db.models import Sum

from transactions.models import Transaction, TransactionType


def get_total_income(account):
    result = (
        Transaction.objects
        .filter(
            account=account,
            type=TransactionType.INCOME,
        )
        .aggregate(total=Sum("amount"))
    )

    return result["total"] or Decimal("0.00")


def get_total_expenses(account):
    result = (
        Transaction.objects
        .filter(
            account=account,
            type=TransactionType.EXPENSE,
        )
        .aggregate(total=Sum("amount"))
    )

    return result["total"] or Decimal("0.00")


def get_current_balance(account):
    income = get_total_income(account)
    expenses = get_total_expenses(account)

    return account.opening_balance + income - expenses

def get_financial_summary(account):
    total_income = get_total_income(account)
    total_expenses = get_total_expenses(account)
    current_balance = (
        account.opening_balance
        + total_income
        - total_expenses
    )

    return {
        "opening_balance": account.opening_balance,
        "total_income": total_income,
        "total_expenses": total_expenses,
        "current_balance": current_balance,
    }

def get_user_financial_summary(user):
    opening_balance_result = (
        Account.objects
        .filter(user=user)
        .aggregate(total=Sum("opening_balance"))
    )

    opening_balance = (
        opening_balance_result["total"]
        or Decimal("0.00")
    )

    income_result = (
        Transaction.objects
        .filter(
            account__user=user,
            type=TransactionType.INCOME,
        )
        .aggregate(total=Sum("amount"))
    )

    total_income = (
        income_result["total"]
        or Decimal("0.00")
    )

    expense_result = (
        Transaction.objects
        .filter(
            account__user=user,
            type=TransactionType.EXPENSE,
        )
        .aggregate(total=Sum("amount"))
    )

    total_expenses = (
        expense_result["total"]
        or Decimal("0.00")
    )

    current_balance = (
        opening_balance
        + total_income
        - total_expenses
    )

    return {
        "opening_balance": opening_balance,
        "total_income": total_income,
        "total_expenses": total_expenses,
        "current_balance": current_balance,
    }

def get_user_monthly_summary(user, year, month):
    transactions = Transaction.objects.filter(
        account__user=user,
        occurred_on__year=year,
        occurred_on__month=month,
    )

    income_result = transactions.filter(
        type=TransactionType.INCOME,
    ).aggregate(
        total=Sum("amount")
    )

    total_income = (
        income_result["total"]
        or Decimal("0.00")
    )

    expense_result = transactions.filter(
        type=TransactionType.EXPENSE,
    ).aggregate(
        total=Sum("amount")
    )

    total_expenses = (
        expense_result["total"]
        or Decimal("0.00")
    )

    net_result = (
        total_income
        - total_expenses
    )

    return {
        "year": year,
        "month": month,
        "total_income": total_income,
        "total_expenses": total_expenses,
        "net_result": net_result,
    }