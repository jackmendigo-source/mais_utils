from django.conf import settings
from django.db import models

class Account(models.Model):
    class AccountType(models.TextChoices):
        CHECKING = "CHECKING", "Conta corrente"
        SAVINGS = "SAVINGS", "Poupança"
        WALLET = "WALLET", "Carteira digital"
        CASH = "CASH", "Dinheiro"
        OTHER = "OTHER", "Outro"
        
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='accounts'
    )
    
    name = models.CharField(max_length=100)
    
    type = models.CharField(
        max_length=20,
        choices=AccountType.choices,
        default=AccountType.CHECKING
    )
    
    opening_balance = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=0,
    )
    
    currency = models.CharField(
        max_length=3,
        default='BRL',          
    )
    
    is_active = models.BooleanField(default=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.name