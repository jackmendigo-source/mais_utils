from rest_framework.generics import ListCreateAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from accounts.services import get_user_financial_summary, get_user_monthly_summary
from accounts.models import Account
from accounts.serializers import AccountSerializer, MonthlySummaryQuerySerializer


class AccountListCreateView(ListCreateAPIView):
    serializer_class = AccountSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Account.objects.filter(
            user=self.request.user
        ).order_by("name")

    def perform_create(self, serializer):
        serializer.save(
            user=self.request.user
        )

class DashboardSummaryView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        summary = get_user_financial_summary(
            request.user
        )

        return Response(summary)

class DashboardMonthlySummaryView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        query_serializer = MonthlySummaryQuerySerializer(
            data=request.query_params
        )

        query_serializer.is_valid(
            raise_exception=True
        )

        year = query_serializer.validated_data["year"]
        month = query_serializer.validated_data["month"]

        summary = get_user_monthly_summary(
            request.user,
            year=year,
            month=month,
        )

        return Response(summary)