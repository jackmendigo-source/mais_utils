from decimal import Decimal

from django.contrib.auth import get_user_model
from rest_framework import status
from rest_framework.test import APITestCase

from accounts.models import Account


User = get_user_model()


class AccountAPITests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username="joao",
            password="senha-segura-123",
        )

        self.other_user = User.objects.create_user(
            username="maria",
            password="senha-segura-456",
        )

        self.account = Account.objects.create(
            user=self.user,
            name="Nubank",
            opening_balance=Decimal("1000.00"),
        )

        Account.objects.create(
            user=self.other_user,
            name="Banco da Maria",
            opening_balance=Decimal("5000.00"),
        )

    def test_unauthenticated_user_cannot_list_accounts(self):
        response = self.client.get(
            "/api/accounts/"
        )

        self.assertIn(
            response.status_code,
            [
                status.HTTP_401_UNAUTHORIZED,
                status.HTTP_403_FORBIDDEN,
            ],
        )

    def test_user_only_sees_own_accounts(self):
        self.client.force_authenticate(
            user=self.user
        )

        response = self.client.get(
            "/api/accounts/"
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )

        self.assertEqual(
            len(response.data),
            1,
        )

        self.assertEqual(
            response.data[0]["name"],
            "Nubank",
        )

    def test_authenticated_user_can_create_account(self):
        self.client.force_authenticate(
            user=self.user
        )

        data = {
            "name": "Carteira",
            "type": "CASH",
            "opening_balance": "100.00",
            "currency": "BRL",
        }

        response = self.client.post(
            "/api/accounts/",
            data,
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_201_CREATED,
        )

        account = Account.objects.get(
            name="Carteira"
        )

        self.assertEqual(
            account.user,
            self.user,
        )