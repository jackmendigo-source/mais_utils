from decimal import Decimal

from django.contrib.auth import get_user_model

from rest_framework import status
from rest_framework.test import APITestCase

from accounts.models import Account
from transactions.models import (
    Category,
    Transaction,
    TransactionType,
)


User = get_user_model()


class DashboardSummaryAPITests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username="dashboard_user",
            password="senha-segura-123",
        )

        self.other_user = User.objects.create_user(
            username="other_dashboard_user",
            password="senha-segura-456",
        )

        self.account = Account.objects.create(
            user=self.user,
            name="Conta principal",
            opening_balance=Decimal("1000.00"),
        )

        self.income_category = Category.objects.create(
            user=self.user,
            name="Salário",
            type=TransactionType.INCOME,
        )

        self.expense_category = Category.objects.create(
            user=self.user,
            name="Alimentação",
            type=TransactionType.EXPENSE,
        )

        Transaction.objects.create(
            account=self.account,
            category=self.income_category,
            type=TransactionType.INCOME,
            amount=Decimal("2500.00"),
            occurred_on="2026-09-24",
        )

        Transaction.objects.create(
            account=self.account,
            category=self.expense_category,
            type=TransactionType.EXPENSE,
            amount=Decimal("400.00"),
            occurred_on="2026-09-24",
        )
        
    def test_unauthenticated_user_cannot_access_summary(self):
        response = self.client.get(
            "/api/dashboard/summary/"
        )

        self.assertIn(
            response.status_code,
            [
                status.HTTP_401_UNAUTHORIZED,
                status.HTTP_403_FORBIDDEN,
            ],
        )
    
    def test_authenticated_user_receives_financial_summary(self):
        self.client.force_authenticate(
            user=self.user
        )

        response = self.client.get(
            "/api/dashboard/summary/"
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )

        self.assertEqual(
            response.data["opening_balance"],
            Decimal("1000.00"),
        )

        self.assertEqual(
            response.data["total_income"],
            Decimal("2500.00"),
        )

        self.assertEqual(
            response.data["total_expenses"],
            Decimal("400.00"),
        )

        self.assertEqual(
            response.data["current_balance"],
            Decimal("3100.00"),
        )