from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase

from accounts.models import Account
from accounts.services import (
    get_current_balance,
    get_total_expenses,
    get_total_income,
    get_financial_summary,
    get_user_financial_summary,
    get_user_monthly_summary,
)
from transactions.models import (
    Category,
    Transaction,
    TransactionType,
)


User = get_user_model()


class AccountFinancialServiceTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user(
            username="finance_test",
            password="senha-segura-123",
        )

        cls.account = Account.objects.create(
            user=cls.user,
            name="Conta principal",
            opening_balance=Decimal("1000.00"),
        )

        cls.income_category = Category.objects.create(
            user=cls.user,
            name="Salário",
            type=TransactionType.INCOME,
        )

        cls.expense_category = Category.objects.create(
            user=cls.user,
            name="Alimentação",
            type=TransactionType.EXPENSE,
        )
    
    def test_total_income(self):
        Transaction.objects.create(
            account=self.account,
            category=self.income_category,
            type=TransactionType.INCOME,
            amount=Decimal("2500.00"),
            occurred_on="2026-09-24",
        )

        Transaction.objects.create(
            account=self.account,
            category=self.income_category,
            type=TransactionType.INCOME,
            amount=Decimal("500.00"),
            occurred_on="2026-09-24",
        )

        self.assertEqual(
            get_total_income(self.account),
            Decimal("3000.00"),
        )
    
    def test_total_expenses(self):
        Transaction.objects.create(
            account=self.account,
            category=self.expense_category,
            type=TransactionType.EXPENSE,
            amount=Decimal("300.00"),
            occurred_on="2026-09-24",
        )

        Transaction.objects.create(
            account=self.account,
            category=self.expense_category,
            type=TransactionType.EXPENSE,
            amount=Decimal("200.00"),
            occurred_on="2026-09-24",
        )

        self.assertEqual(
            get_total_expenses(self.account),
            Decimal("500.00"),
        )
    
    def test_current_balance(self):
        Transaction.objects.create(
            account=self.account,
            category=self.income_category,
            type=TransactionType.INCOME,
            amount=Decimal("2500.00"),
            occurred_on="2026-09-24",
        )

        Transaction.objects.create(
            account=self.account,
            category=self.expense_category,
            type=TransactionType.EXPENSE,
            amount=Decimal("400.00"),
            occurred_on="2026-09-24",
        )

        self.assertEqual(
            get_current_balance(self.account),
            Decimal("3100.00"),
        )
    def test_current_balance_without_transactions_equals_opening_balance(self):
        self.assertEqual(
            get_total_income(self.account),
            Decimal("0.00"),
        )

        self.assertEqual(
            get_total_expenses(self.account),
            Decimal("0.00"),
        )

        self.assertEqual(
            get_current_balance(self.account),
            Decimal("1000.00"),
        )
    def test_transactions_from_another_account_do_not_affect_balance(self):
        other_account = Account.objects.create(
            user=self.user,
            name="Outra conta",
            opening_balance=Decimal("5000.00"),
        )

        Transaction.objects.create(
            account=other_account,
            category=self.income_category,
            type=TransactionType.INCOME,
            amount=Decimal("10000.00"),
            occurred_on="2026-09-24",
        )

        Transaction.objects.create(
            account=other_account,
            category=self.expense_category,
            type=TransactionType.EXPENSE,
            amount=Decimal("3000.00"),
            occurred_on="2026-09-24",
        )

        self.assertEqual(
            get_total_income(self.account),
            Decimal("0.00"),
        )

        self.assertEqual(
            get_total_expenses(self.account),
            Decimal("0.00"),
        )

        self.assertEqual(
            get_current_balance(self.account),
            Decimal("1000.00"),
        )
    
    def test_financial_summary(self):
        Transaction.objects.create(
            account=self.account,
            category=self.income_category,
            type=TransactionType.INCOME,
            amount=Decimal("2500.00"),
            occurred_on="2026-09-24",
        )

        Transaction.objects.create(
            account=self.account,
            category=self.expense_category,
            type=TransactionType.EXPENSE,
            amount=Decimal("400.00"),
            occurred_on="2026-09-24",
        )

        summary = get_financial_summary(self.account)

        self.assertEqual(
            summary,
            {
                "opening_balance": Decimal("1000.00"),
                "total_income": Decimal("2500.00"),
                "total_expenses": Decimal("400.00"),
                "current_balance": Decimal("3100.00"),
            },
        )
    
    def test_user_financial_summary_combines_accounts(self):
        second_account = Account.objects.create(
            user=self.user,
            name="Segunda conta",
            opening_balance=Decimal("500.00"),
        )

        Transaction.objects.create(
            account=self.account,
            category=self.income_category,
            type=TransactionType.INCOME,
            amount=Decimal("2000.00"),
            occurred_on="2026-09-24",
        )

        Transaction.objects.create(
            account=second_account,
            category=self.expense_category,
            type=TransactionType.EXPENSE,
            amount=Decimal("300.00"),
            occurred_on="2026-09-24",
        )

        summary = get_user_financial_summary(self.user)

        self.assertEqual(
            summary,
            {
                "opening_balance": Decimal("1500.00"),
                "total_income": Decimal("2000.00"),
                "total_expenses": Decimal("300.00"),
                "current_balance": Decimal("3200.00"),
            },
        )
    def test_user_monthly_summary_only_includes_selected_month(self):
        Transaction.objects.create(
            account=self.account,
            category=self.income_category,
            type=TransactionType.INCOME,
            amount=Decimal("3000.00"),
            occurred_on="2026-09-05",
        )

        Transaction.objects.create(
            account=self.account,
            category=self.expense_category,
            type=TransactionType.EXPENSE,
            amount=Decimal("700.00"),
            occurred_on="2026-09-10",
        )

        Transaction.objects.create(
            account=self.account,
            category=self.expense_category,
            type=TransactionType.EXPENSE,
            amount=Decimal("1000.00"),
            occurred_on="2026-08-20",
        )

        summary = get_user_monthly_summary(
            self.user,
            year=2026,
            month=9,
        )

        self.assertEqual(
            summary["total_income"],
            Decimal("3000.00"),
        )

        self.assertEqual(
            summary["total_expenses"],
            Decimal("700.00"),
        )

        self.assertEqual(
            summary["net_result"],
            Decimal("2300.00"),
        )
    
    def test_user_monthly_summary_without_transactions_returns_zero(self):
        summary = get_user_monthly_summary(
            self.user,
            year=2026,
            month=12,
        )

        self.assertEqual(
            summary["total_income"],
            Decimal("0.00"),
        )

        self.assertEqual(
            summary["total_expenses"],
            Decimal("0.00"),
        )

        self.assertEqual(
            summary["net_result"],
            Decimal("0.00"),
        )