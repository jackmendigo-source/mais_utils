# Meu Financeiro

Aplicativo de controle e planejamento financeiro pessoal.

## Backend

- Python
- Django
- Django REST Framework
- PostgreSQL

## Status

Projeto em desenvolvimento.